package com.example.yopin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class RegisterActivity extends AppCompatActivity {
    private EditText etEmail, etPassword, etFullName, etBirthDate, etVerificationCode;
    private Button btnRegister, btnSendCode;
    private DatabaseHelper dbHelper;
    private String verificationCode;
    private boolean codeSent = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = new DatabaseHelper(this);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etFullName = findViewById(R.id.etFullName);
        etBirthDate = findViewById(R.id.etBirthDate);
        etVerificationCode = findViewById(R.id.etVerificationCode);
        btnRegister = findViewById(R.id.btnRegister);
        btnSendCode = findViewById(R.id.btnSendCode);

        btnSendCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendVerificationCode();
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });
    }

    private void sendVerificationCode() {
        String email = etEmail.getText().toString().trim();
        if (email.isEmpty()) {
            Toast.makeText(this, "Введите email", Toast.LENGTH_SHORT).show();
            return;
        }

        // Генерация 6-значного кода
        Random random = new Random();
        verificationCode = String.format("%06d", random.nextInt(999999));

        // В реальном приложении здесь должна быть отправка email
        // Для демонстрации просто показываем код в Toast
        Toast.makeText(this, "Код подтверждения: " + verificationCode, Toast.LENGTH_LONG).show();

        codeSent = true;
        etVerificationCode.setVisibility(View.VISIBLE);
        btnRegister.setEnabled(true);
    }

    private void registerUser() {
        if (!codeSent) {
            Toast.makeText(this, "Сначала отправьте код подтверждения", Toast.LENGTH_SHORT).show();
            return;
        }

        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String fullName = etFullName.getText().toString().trim();
        String birthDate = etBirthDate.getText().toString().trim();
        String enteredCode = etVerificationCode.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty() || fullName.isEmpty() || birthDate.isEmpty()) {
            Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!enteredCode.equals(verificationCode)) {
            Toast.makeText(this, "Неверный код подтверждения", Toast.LENGTH_SHORT).show();
            return;
        }

        // Генерируем юзернейм из email (часть до @)
        String username = email.split("@")[0];

        if (dbHelper.addUser(email, password, fullName, username, birthDate)) {
            Toast.makeText(this, "Регистрация успешна", Toast.LENGTH_SHORT).show();

            // Переход в список книг
            Intent intent = new Intent(RegisterActivity.this, BooksActivity.class);
            intent.putExtra("email", email);
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(this, "Ошибка регистрации", Toast.LENGTH_SHORT).show();
        }
    }
}
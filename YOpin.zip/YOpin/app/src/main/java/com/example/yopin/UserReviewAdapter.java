package com.example.yopin;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class UserReviewAdapter extends RecyclerView.Adapter<UserReviewAdapter.UserReviewViewHolder> {
    private List<Review> reviews;

    public UserReviewAdapter(List<Review> reviews) {
        this.reviews = reviews;
    }

    @NonNull
    @Override
    public UserReviewViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_user_review, parent, false);
        return new UserReviewViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull UserReviewViewHolder holder, int position) {
        Review review = reviews.get(position);
        
        if (review.getBookId() > 0) {
            holder.tvBookInfo.setText(review.getBookTitle() + " - " + review.getBookAuthor());
            holder.tvBookInfo.setVisibility(View.VISIBLE);
        } else {
            holder.tvBookInfo.setVisibility(View.GONE);
        }
        
        holder.tvReviewText.setText(review.getReviewText());
        holder.tvReviewDate.setText(review.getDate());
        holder.ratingBar.setRating(review.getRating());
        
        // Показываем рейтинг только если он установлен
        if (review.getRating() > 0) {
            holder.ratingBar.setVisibility(View.VISIBLE);
        } else {
            holder.ratingBar.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return reviews.size();
    }

    public class UserReviewViewHolder extends RecyclerView.ViewHolder {
        TextView tvBookInfo, tvReviewText, tvReviewDate;
        RatingBar ratingBar;

        public UserReviewViewHolder(@NonNull View itemView) {
            super(itemView);
            tvBookInfo = itemView.findViewById(R.id.tvBookInfo);
            tvReviewText = itemView.findViewById(R.id.tvReviewText);
            tvReviewDate = itemView.findViewById(R.id.tvReviewDate);
            ratingBar = itemView.findViewById(R.id.ratingBar);
        }
    }
} 